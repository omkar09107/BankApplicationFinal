package project.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.dao.ProjectImp;
import project.dao.ProjectInterface;
import project.model.Neft;

/**
 * Servlet implementation class NeftModifyController
 */
@WebServlet("/NeftModifyController")
public class NeftModifyController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public NeftModifyController() {
		super();
		// TODO Auto-generated constructor stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Neft> nlst=new ArrayList<Neft>();
		HttpSession session=request.getSession(true);
		nlst=(List<Neft>)session.getAttribute("data");
		Neft n=nlst.get(0);
		ProjectInterface pobj=new ProjectImp();
		int i=pobj.neftTransfer(nlst);
		System.out.println(i);

		System.out.println("test4");

		if (i > 0) {
			response.sendRedirect("NeftDone.jsp");

		}   else {
			response.sendRedirect("TransactionFailed.jsp");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
