package project.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import project.dao.ProjectImp;
import project.model.Login;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public LoginController() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uName = request.getParameter("uName");
        String password = request.getParameter("password");
        
        Login lobj = new Login(uName, password);
        
        ProjectImp pobj = new ProjectImp();
        boolean isValidCredentials = pobj.validateCredentials(lobj);
        
        if(isValidCredentials) {
        	HttpSession session = request.getSession();
        	 session.setAttribute("uName", uName);
             session.setAttribute("password", password);

            response.sendRedirect("DashboardView.jsp");
        } else {
        	  request.setAttribute("errorMessage", "Invalid username or password");
              RequestDispatcher dispatcher = request.getRequestDispatcher("LoginView.jsp");
              dispatcher.forward(request, response);
        }
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
